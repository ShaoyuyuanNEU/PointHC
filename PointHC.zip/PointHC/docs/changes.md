# Change Logs & TODOs


## Change Logs
- [2022/08/21] Added ShapeNetPart and ScanNet. Support AMP. 
- [2022/07/09] Initial Realse


## TODO
- [ ] clean segmentation
- [ ] support multi-gpu testing for segmentation tasks