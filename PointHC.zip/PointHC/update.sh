#!/usr/bin/env bash
git pull --recurse-submodules